startupText = `
══════════════ Welcome To ════════════════

██████╗ ███████╗ █████╗  ██████╗ ██████╗ ███╗   ██╗
██╔══██╗██╔════╝██╔══██╗██╔════╝██╔═══██╗████╗  ██║
██████╔╝█████╗  ███████║██║     ██║   ██║██╔██╗ ██║
██╔══██╗██╔══╝  ██╔══██║██║     ██║   ██║██║╚██╗██║
██████╔╝███████╗██║  ██║╚██████╗╚██████╔╝██║ ╚████║
╚═════╝ ╚══════╝╚═╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═╝  ╚═══╝

Beacon is a professional text and code editor based on ace and inspired by sublime text.
Beacon also has a handy serial terminal emulator.

╔═╗┌─┐┌┬┐  ╔═╗┌┬┐┌─┐┬─┐┌┬┐┌─┐┌┬┐
║ ╦├┤  │   ╚═╗ │ ├─┤├┬┘ │ ├┤  ││
╚═╝└─┘ ┴   ╚═╝ ┴ ┴ ┴┴└─ ┴ └─┘─┴┘

To get started editing, click either "File > New", or "File > Open".
You can change the editor settings and theme by clicking "Settings > Simple Settings"

To get started with the serial terminal, select the correct device, and press "Connect".
You can change the terminal theme by clicking the Gear icon, and changing the appropriate dropdown.

`